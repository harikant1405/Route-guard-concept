import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { EditAboutComponent } from './edit-about/edit-about.component';
import { ProductsComponent } from './products/products.component';
import { ContactComponent } from './contact/contact.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuard } from './services/auth.guard';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { RoleGuard } from './services/role.guard';
import { ConditionBasedGuard } from './services/condition-based.guard';
import { ModuleGuard } from './services/module.guard';
import { ResolveGuard } from './services/resolve.guard';

const routes: Routes = [
  {path: '' , redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {
    path: 'about',
    component: AboutComponent,
    canActivateChild: [ RoleGuard ],
    children: [
      {
        path:'edit-about',
        component: EditAboutComponent
      }
    ]
  },
  {
    path: 'products',
    component: ProductsComponent,
    resolve: { data : ResolveGuard }
  },
  {
    path: 'contact',
    component: ContactComponent,
    canDeactivate: [ConditionBasedGuard]
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'offers',
    canLoad: [ ModuleGuard ],
    loadChildren: () => 
      import('./offers/offers.module').then((m) => m.OffersModule)
  },
  {
    path: 'access-denied',
    component: AccessDeniedComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
