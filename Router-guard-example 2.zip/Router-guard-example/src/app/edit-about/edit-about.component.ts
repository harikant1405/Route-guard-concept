import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-about',
  templateUrl: './edit-about.component.html',
  styleUrls: ['./edit-about.component.css']
})
export class EditAboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
