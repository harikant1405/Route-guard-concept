import { Injectable } from '@angular/core';
import { delay, interval, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

  getData() {
    return of('ResolveGuardData').pipe(delay(3000));
  }
}
