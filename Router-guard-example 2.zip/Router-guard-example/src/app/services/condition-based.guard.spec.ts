import { TestBed } from '@angular/core/testing';

import { ConditionBasedGuard } from './condition-based.guard';

describe('ConditionBasedGuard', () => {
  let guard: ConditionBasedGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ConditionBasedGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
